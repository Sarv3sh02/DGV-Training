package com.example.tictactoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var dataStored= arrayOf<String>()

        var playBox1=findViewById<TextView>(R.id.playBox1)
        var playBox2=findViewById<TextView>(R.id.playBox2)
        var playBox3=findViewById<TextView>(R.id.playBox3)
        var playBox4=findViewById<TextView>(R.id.playBox4)
        var playBox5=findViewById<TextView>(R.id.playBox5)
        var playBox6=findViewById<TextView>(R.id.playBox6)
        var playBox7=findViewById<TextView>(R.id.playBox7)
        var playBox8=findViewById<TextView>(R.id.playBox8)
        var playBox9=findViewById<TextView>(R.id.playBox9)
        var winnerDisplay=findViewById<TextView>(R.id.winnerDisplay)
        var playAgainBtn=findViewById<Button>(R.id.playAgainBtn)

        var count:Int=0
        fun gameWork() {
             dataStored= arrayOf<String>("1","2","3","4","5","6","7","8","9")
            fun winnerCheck() {

                if (dataStored[0] == dataStored[1] && dataStored[1] == dataStored[2] ||
                    dataStored[3] == dataStored[4] && dataStored[4] == dataStored[5] ||
                    dataStored[6] == dataStored[7] && dataStored[7] == dataStored[8] ||
                    dataStored[0] == dataStored[3] && dataStored[3] == dataStored[6] ||
                    dataStored[1] == dataStored[4] && dataStored[4] == dataStored[7] ||
                    dataStored[2] == dataStored[5] && dataStored[5] == dataStored[8] ||
                    dataStored[0] == dataStored[4] && dataStored[4] == dataStored[8] ||
                    dataStored[2] == dataStored[4] && dataStored[4] == dataStored[6]
                ) {
                    if (count % 2 == 0) {
                        winnerDisplay.text = "Player2 Wins"
                    } else {
                        winnerDisplay.text = "Player1 Wins"
                    }
                }
                else if(count>=9 && dataStored[8]!=""){
                    winnerDisplay.text="Draw"
                }
            }

            playBox1.setOnClickListener {
                count++
                if (count % 2 == 0) {
                    playBox1.text = "O"
                    dataStored[0] = "O"
                } else {
                    playBox1.text = "X"
                    dataStored[0] = "X"
                }
                winnerCheck()
            }

            playBox2.setOnClickListener {
                count++
                if (count % 2 == 0) {
                    playBox2.text = "O"
                    dataStored[1] = "O"
                } else {
                    playBox2.text = "X"
                    dataStored[1] = "X"
                }
                winnerCheck()
            }

            playBox3.setOnClickListener {
                count++
                if (count % 2 == 0) {
                    playBox3.text = "O"
                    dataStored[2] = "O"
                } else {
                    playBox3.text = "X"
                    dataStored[2] = "X"
                }
                winnerCheck()
            }

            playBox4.setOnClickListener {
                count++
                if (count % 2 == 0) {
                    playBox4.text = "O"
                    dataStored[3] = "O"
                } else {
                    playBox4.text = "X"
                    dataStored[3] = "X"
                }
                winnerCheck()
            }

            playBox5.setOnClickListener {
                count++
                if (count % 2 == 0) {
                    playBox5.text = "O"
                    dataStored[4] = "O"
                } else {
                    playBox5.text = "X"
                    dataStored[4] = "X"
                }
                winnerCheck()
            }

            playBox6.setOnClickListener {
                count++
                if (count % 2 == 0) {
                    playBox6.text = "O"
                    dataStored[5] = "O"
                } else {
                    playBox6.text = "X"
                    dataStored[5] = "X"
                }
                winnerCheck()
            }

            playBox7.setOnClickListener {
                count++
                if (count % 2 == 0) {
                    playBox7.text = "O"
                    dataStored[6] = "O"
                } else {
                    playBox7.text = "X"
                    dataStored[6] = "X"
                }
                winnerCheck()
            }

            playBox8.setOnClickListener {
                count++
                if (count % 2 == 0) {
                    playBox8.text = "O"
                    dataStored[7] = "O"
                } else {
                    playBox8.text = "X"
                    dataStored[7] = "X"
                }
                winnerCheck()
            }

            playBox9.setOnClickListener {
                count++
                if (count % 2 == 0) {
                    playBox9.text = "O"
                    dataStored[8] = "O"
                } else {
                    playBox9.text = "X"
                    dataStored[8] = "X"
                }
                winnerCheck()
            }
        }
        gameWork()

        playAgainBtn.setOnClickListener{
            playBox1.text=" "
            playBox2.text=" "
            playBox3.text=" "
            playBox4.text=" "
            playBox5.text=" "
            playBox6.text=" "
            playBox7.text=" "
            playBox8.text=" "
            playBox9.text=" "
            winnerDisplay.text=" "
            count=0
//            dataStored= arrayOf<String>("1","2","3","4","5","6","7","8","9")
            gameWork()
        }

    }
}