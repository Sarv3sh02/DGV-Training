package com.example.dabbewala

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.widget.TextView
import org.w3c.dom.Text

class SplashScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_screen)


        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        val textSplash=findViewById<TextView>(R.id.textSplash)
        val textVersion=findViewById<TextView>(R.id.textVersion)
        val slideAnimation = AnimationUtils.loadAnimation(this, R.anim.slide_animation)
        textSplash.startAnimation(slideAnimation)
        textVersion.startAnimation(slideAnimation)

//        Made to display starting screen
        Handler().postDelayed(Runnable {
            val i = Intent(this@SplashScreen, MainActivity::class.java)
            startActivity(i)
            finish()
        }, 2000)
    }

}