package com.example.dabbewala

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dabbewala.adapters.locationAdapter

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.location_display)

//        Defining the view's used for searching
        var searchbar=findViewById<EditText>(R.id.locationSearch)
        var searchButton=findViewById<Button>(R.id.searchButton)

//        Defining recycler view for location list
        var locationRecyclerView:RecyclerView=findViewById(R.id.locationRecycler)
        locationRecyclerView.layoutManager=GridLayoutManager(this,2)

//        Object of data class
        var itemDataViewModel:ItemDataViewModel=ViewModelProvider(this).get(ItemDataViewModel::class.java)

        locationRecyclerView.adapter=locationAdapter(this,itemDataViewModel.locations)

//        Searchbar logic
        searchButton.setOnClickListener{
            var locList= mutableListOf<String>()
            for(i in 0 until itemDataViewModel.locations.size){
                if(searchbar.text.toString()==itemDataViewModel.locations.get(i)){
                    locList.add(itemDataViewModel.locations.get(i))
                    Log.d("data","${locList.get(0)}")
                }
            }
        locationRecyclerView.adapter=locationAdapter(this,locList)
        }
        locationRecyclerView.layoutManager=GridLayoutManager(this,2)
    }

}