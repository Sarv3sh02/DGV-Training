package com.example.dabbewala

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.example.dabbewala.adapters.swipperAdapter
import com.google.android.material.snackbar.Snackbar

class ItemDisplay : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.item_display)

        val itemDataViewModel:ItemDataViewModel=ViewModelProvider(this).get(ItemDataViewModel::class.java)

//        Getting intent from itemAdapter
        val id=intent.getStringExtra("id")!!.toInt()

        var item:Item=itemDataViewModel.items.get(0)

//        Getting data on basis of food place user selected
        for(i in 0 until itemDataViewModel.items.size){
            if(itemDataViewModel.items.get(i).id==id){
                item=itemDataViewModel.items.get(i)
                //index=i
            }
        }

//        Fetching the view's
        val singleAddress=findViewById<TextView>(R.id.singleAddress)
        val singlePlace=findViewById<TextView>(R.id.singlePlace)
        val singlePrice=findViewById<TextView>(R.id.singlePrice)
        val phoneNo=findViewById<TextView>(R.id.phoneNo)
        val description=findViewById<TextView>(R.id.description)
        val orderButton=findViewById<Button>(R.id.orderButton)

//        Putting the data in view's fetched above
        singleAddress.text=item.address
//        singleImage.setImageResource(item.image[0])
        singlePlace.text=item.placeName
        singlePrice.text=item.mealPrice
        phoneNo.text=item.phoneNumber.toString()
        description.text=item.description


        val SelectOption=resources.getStringArray(R.array.SelectOption)

        var spinner=findViewById<Spinner>(R.id.spinnerOption)
        if(spinner!=null){
            val adapter = ArrayAdapter(this,
                android.R.layout.simple_spinner_item, SelectOption)
            spinner.adapter = adapter
        }

//        Order button
        orderButton.setOnClickListener{
            val snackbar=Snackbar.make(it,"Successfully Ordered",Snackbar.LENGTH_LONG)
            snackbar.show()
        }


        val viewPager=findViewById<ViewPager2>(R.id.viewPager)
        viewPager.adapter=swipperAdapter(this,item.image)


    }
}