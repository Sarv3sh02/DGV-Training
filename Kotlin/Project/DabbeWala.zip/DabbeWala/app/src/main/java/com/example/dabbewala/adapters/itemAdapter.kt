package com.example.dabbewala.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.dabbewala.Item
import com.example.dabbewala.ItemDisplay
import com.example.dabbewala.R

class itemAdapter(var context: Context, var items:List<Item>):RecyclerView.Adapter<itemAdapter.ViewHolder>() {
    //    Inflating data in the layout
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context)
            .inflate
             (R.layout.items_list,parent,false)
        )
    }
    //    Binding the data we need to show in the recycler view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item=items.get(position)
        holder.placeName.text=item.placeName
        holder.itemImage.setImageResource(item.image[0])
        holder.mealPrice.text=item.mealPrice.toString()

        holder.layout1.setOnClickListener{
            val itemIntent= Intent(context,ItemDisplay::class.java)
            itemIntent.putExtra("id",item.id.toString())
            context.startActivity(itemIntent)
        }
    }
    //    Size of list taken a parameter
    override fun getItemCount(): Int {
        return items.size
    }
    //    Defining ViewHolder class to fetch the view's
    class ViewHolder(view: View): RecyclerView.ViewHolder(view){
        var itemImage=view.findViewById<ImageView>(R.id.itemImage)
        var placeName=view.findViewById<TextView>(R.id.placeName)
        var mealPrice=view.findViewById<TextView>(R.id.mealPrice)
        var layout1=view.findViewById<LinearLayout>(R.id.layout1)
    }

}