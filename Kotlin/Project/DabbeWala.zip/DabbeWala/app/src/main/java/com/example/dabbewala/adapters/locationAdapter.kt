package com.example.dabbewala.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.dabbewala.ItemsDisplay
import com.example.dabbewala.R


class locationAdapter(var context: Context, var locations:List<String>):RecyclerView.Adapter<locationAdapter.ViewHolder>() {

//    Inflating data in the layout
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context)
            .inflate
            (R.layout.location_place,parent,false)
        )
    }

//    Binding the data we need to show in the recycler view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val location=locations.get(position)
        holder.locationDisplay.text=location
        holder.locationDisplay.setOnClickListener{
            val locationIntent= Intent(context, ItemsDisplay::class.java)
            locationIntent.putExtra("locationCategory",location)
            context.startActivity(locationIntent)
        }
    }

//    Size of list taken a parameter
    override fun getItemCount(): Int {
        return locations.size
    }
//    Defining ViewHolder class and fetching view's
    class ViewHolder(view: View):RecyclerView.ViewHolder(view){
        var locationDisplay=view.findViewById<TextView>(R.id.locationDisplay)
    }

}