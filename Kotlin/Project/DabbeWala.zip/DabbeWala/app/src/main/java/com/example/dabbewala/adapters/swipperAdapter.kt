package com.example.dabbewala.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.example.dabbewala.R

class swipperAdapter(val context:Context,val imgList:Array<Int>):RecyclerView.Adapter<swipperAdapter.Viewholder>() {

    class Viewholder(view: View): RecyclerView.ViewHolder(view)
    {
        val imgSwipe=view.findViewById<ImageView>(R.id.imgSwipe)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Viewholder {
        return Viewholder(
            LayoutInflater.from(context).inflate(R.layout.swipper_image,parent,false)
        )
    }
    override fun onBindViewHolder(holder: Viewholder, position: Int) {
        var image= imgList[position]
        holder.imgSwipe.setImageResource(image)
    }
    override fun getItemCount(): Int {
        return imgList.size
    }

}