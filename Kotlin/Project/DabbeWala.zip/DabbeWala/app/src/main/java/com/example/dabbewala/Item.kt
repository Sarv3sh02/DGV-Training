package com.example.dabbewala

//    Item class to define the paramete's of an item
class Item(placeName:String, mealPrice:String, image:Array<Int>, locationCategory:String, id:Int, phoneNumber:Int, address:String, desc:String) {

    var placeName:String
    var mealPrice:String
    var image:Array<Int>
    var locationCategory:String
    var id:Int
    var phoneNumber:Int
    var address:String
    var description:String

    init{
        this.placeName=placeName
        this.mealPrice=mealPrice
        this.image=image
        this.locationCategory=locationCategory
        this.id=id
        this.phoneNumber=phoneNumber
        this.address=address
        this.description=desc
    }

}