package com.example.dabbewala

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dabbewala.adapters.itemAdapter

class ItemsDisplay : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.items_display)

//        Defining recycler view for food places displaly
        var itemRecycler:RecyclerView=findViewById(R.id.itemRecycler)
        itemRecycler.layoutManager=GridLayoutManager(this,2)

//        Object of data class
        var itemDataViewModel:ItemDataViewModel=ViewModelProvider(this).get(ItemDataViewModel::class.java)

//        Getting the intent from locationAdapter
        var locationCategory=intent.getStringExtra("locationCategory")

        var locationList= mutableListOf<Item>()

//        Logic for displaying food places on basis of location
        for(i in 0 until itemDataViewModel.items.size){
            if(itemDataViewModel.items.get(i).locationCategory==locationCategory){
                locationList.add(itemDataViewModel.items.get(i))
            }
        }
        itemRecycler.adapter=itemAdapter(this,locationList)
    }
}