package com.example.audioplayer

import androidx.lifecycle.ViewModel

class SongData: ViewModel(){

    var songs = listOf<Song>(
        Song(1,"Game Over","Karan Aujla",R.drawable.gameover,R.raw.gameover,"Punjabi"),
        Song(2,"Goat","Diljit Dosanjh",R.drawable.goat,R.raw.goat,"Punjabi"),
        Song(3,"Let Em PLay","Karan Aujla",R.drawable.letemplay,R.raw.letemplay,"Punjabi"),
        Song(4,"No Need","Karan Aujla",R.drawable.noneed,R.raw.noneed,"Punjabi"),
        Song(5,"Oouuu","Karan Aujla",R.drawable.oouu,R.raw.oouuu,"Punjabi"),

        Song(6,"YKWIM","Karan Aujla",R.drawable.gameover,R.raw.ykwim,"Pop"),
        Song(7,"We Rollin","Shubh",R.drawable.goat,R.raw.weroll,"Pop"),
        Song(8,"Gangsta","Karan Aujla",R.drawable.letemplay,R.raw.gangsta,"Pop"),
        Song(9,"Desi Dan Bilzerian","King",R.drawable.noneed,R.raw.desidanbilzerian,"Pop"),
        Song(10,"Celebrity Killer","Sidhu Moosewala",R.drawable.oouu,R.raw.celebritykiller,"Pop"),

        Song(11,"I Guess","Krsna",R.drawable.ic_launcher_background,R.raw.iguess,"Hip-Hop"),
        Song(12,"Gunehgar","Divine",R.drawable.ic_launcher_background,R.raw.gunehgar,"Hip-Hop"),
        Song(13,"Kohinoor","Divine",R.drawable.ic_launcher_background,R.raw.kohinoor,"Hip-Hop"),
        Song(14,"Maakasam","Krsna",R.drawable.ic_launcher_background,R.raw.makasam,"Hip-Hop"),
        Song(15,"Nanchaku","Seedhe Maut",R.drawable.ic_launcher_background,R.raw.nanchaku,"Hip-Hop"),

        Song(16,"Notorious","Wazir Patar",R.drawable.ic_launcher_foreground,R.raw.notorious,"English"),
        Song(17,"These Days","Sidhu Moosewala",R.drawable.ic_launcher_foreground,R.raw.thesedays,"English"),
        Song(18,"Image","Raftaar",R.drawable.ic_launcher_foreground,R.raw.image,"English"),
        Song(19,"The Last Ride","Sidhu Moosewala",R.drawable.ic_launcher_foreground,R.raw.thelastride,"English"),
        Song(20,"Maujjan","Sikander Kahlon",R.drawable.ic_launcher_foreground,R.raw.maujjan,"English"),

        Song(21,"Love Dose","Honey Singh",R.drawable.ic_launcher_background,R.raw.lovedose,"Hindi"),
        Song(22,"Blue Eyes","Honey Singh",R.drawable.ic_launcher_background,R.raw.blueeyes,"Hindi"),
        Song(23,"Baller","Shubh",R.drawable.ic_launcher_background,R.raw.baller,"Hindi"),
        Song(24,"Cash Money","Sikander Kahlon",R.drawable.ic_launcher_background,R.raw.cashmoney,"Hindi"),
        Song(25,"Invincible","SIdhu Moosewala",R.drawable.ic_launcher_background,R.raw.invincible,"Hindi")
    )

    var genre = listOf<String>(
        "Punjabi",
        "Pop",
        "Hip-Hop",
        "English",
        "Hindi"

    )

}
