package com.example.audioplayer

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class GenreListAdapter(val context: Context, val genres:List<String>): RecyclerView.Adapter<GenreListAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context).inflate(R.layout.song_genre,parent,false)
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val genre=genres.get(position)
        holder.genreDisplay.text=genre

        holder.genreDisplay.setOnClickListener{
            val intent=Intent(context,MainActivity::class.java)
            intent.putExtra("genre",genre)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return genres.size
    }

    class ViewHolder(view: View): RecyclerView.ViewHolder(view){
        var genreDisplay=view.findViewById<TextView>(R.id.genreDisplay)
    }

}