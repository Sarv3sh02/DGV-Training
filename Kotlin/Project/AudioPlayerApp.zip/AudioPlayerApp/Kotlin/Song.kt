package com.example.audioplayer

class Song(id:Int, songName:String, artistName:String, thumbnail:Int, audio:Int, genre:String) {

    var id:Int
    var songName:String?=null
    var artistName:String?=null
    var thumbnail:Int
    var audio:Int
    var genre:String?=null


    init {
     this.id=id
     this.songName=songName
     this.artistName=artistName
     this.thumbnail=thumbnail
     this.audio=audio
     this.genre=genre

    }



}