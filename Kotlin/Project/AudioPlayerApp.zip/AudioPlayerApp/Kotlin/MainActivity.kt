package com.example.audioplayer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var recyclerView=findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager=LinearLayoutManager(this)

        var songViewModel:SongData=ViewModelProvider(this).get(SongData::class.java)
        var listAdapter:ListAdapter

        var genre=intent.getStringExtra("genre")

        var genreList= mutableListOf<Song>()

        for(i in 0 until songViewModel.songs.size){
            if(songViewModel.songs.get(i).genre==genre){
                genreList.add(songViewModel.songs.get(i))
            }
        }
        listAdapter=ListAdapter(this,genreList)
        recyclerView.adapter=listAdapter

    }
}