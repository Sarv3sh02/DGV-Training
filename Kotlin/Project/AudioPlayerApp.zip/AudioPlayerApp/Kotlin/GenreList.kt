package com.example.audioplayer

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class GenreList:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.genre_layout)

        var searchBar=findViewById<EditText>(R.id.searchBar)
        var searchBtn=findViewById<Button>(R.id.searchBtn)

        var recyclerView=findViewById<RecyclerView>(R.id.recyclerViewGenre)


        var songViewModel:SongData= ViewModelProvider(this).get(SongData::class.java)
        var GenreListAdapter=GenreListAdapter(this,songViewModel.genre)

        recyclerView.adapter=GenreListAdapter

        searchBtn.setOnClickListener{
            var list1 = mutableListOf<Song>()
            for(i in 0 until songViewModel.songs.size) {
                if(searchBar.text.toString()==songViewModel.songs.get(i).songName) {
                    list1.add(songViewModel.songs.get(i))
                }
            }
            var listAdapter = ListAdapter(this, list1)
            recyclerView.adapter=listAdapter
        }
        recyclerView.layoutManager= LinearLayoutManager(this)
    }
}