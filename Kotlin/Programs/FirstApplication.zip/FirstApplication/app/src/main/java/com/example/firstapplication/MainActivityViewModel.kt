package com.example.firstapplication

import androidx.lifecycle.ViewModel

class MainActivityViewModel: ViewModel() {
    var userBmi=0.0
    var status:String=""

    fun setBmi(userBmi:Double){
        this.userBmi=userBmi
    }

    fun giveStatus(status:String){
        this.status=status
    }
}