package com.example.firstapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var mainActivityViewModel:MainActivityViewModel=ViewModelProvider(this).get(MainActivityViewModel::class.java)

        var constraintLayout=findViewById<ConstraintLayout>(R.id.constLay)


        val enterHeight=findViewById<EditText>(R.id.enterHeight)
        val enterWeight=findViewById<EditText>(R.id.enterWeight)
        val calcButton=findViewById<Button>(R.id.calcButton)
        val bmiResult=findViewById<TextView>(R.id.bmiResult)
        val bmiRange=findViewById<TextView>(R.id.bmiRange)

        bmiResult.text=mainActivityViewModel.userBmi.toInt().toString()
        bmiRange.text=mainActivityViewModel.status

        calcButton.setOnClickListener{
            val userHeight=enterHeight.text.toString()
            val userWeight=enterWeight.text.toString()

            if(userHeight != "" && userWeight != ""){

                var heightMeter = userHeight.toDouble()/100
                var bmiValue=userWeight.toDouble()/(heightMeter*heightMeter)
                mainActivityViewModel.setBmi(bmiValue)
                bmiResult.text=mainActivityViewModel.userBmi.toInt().toString()
                var status:String=""
                when{
                    bmiValue<18.5->{
                        status="UnderWeight"
                    }
                    bmiValue>=18.5 && bmiValue<=24.9->{
                        status="Healthy"
                    }
                    bmiValue>24.9 && bmiValue<=29.9->{
                        status="OverWeight"
                    }
                    bmiValue>29.9->{
                        status="Obese"
                    }
                }
                bmiRange.text=status
                mainActivityViewModel.giveStatus(status)

            }
            else{
                var snackbar=Snackbar.make(constraintLayout,"Please enter valid height nad weight",Snackbar.LENGTH_LONG)
                snackbar.show()
            }
        }

    }
}